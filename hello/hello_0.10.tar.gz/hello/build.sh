dpkg-buildpackage -us -uc
dpkb -b debian/hello
