dpkg-buildpackage -us -uc
dpkg -b debian/hello
