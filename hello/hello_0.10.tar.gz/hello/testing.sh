#!/bin/bash

echo "this is a test from ted"
